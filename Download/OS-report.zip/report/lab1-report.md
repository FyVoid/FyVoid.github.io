# lab1实验报告

## Thinking 1.1

> Thinking 1.1 请阅读附录中的编译链接详解，尝试分别使用实验环境中的原生x86 工具
>
> 链（gcc、ld、readelf、objdump 等）和MIPS 交叉编译工具链（带有mips-linux-gnu-前缀），重复其中的编译和解析过程，观察相应的结果，并解释其中向objdump 传入的参数
>
> 的含义。

```
mips-linux-gnu-gcc -E test.c:

# 1 "test.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 31 "<command-line>"
# 1 "/usr/mips-linux-gnu/include/stdc-predef.h" 1 3
# 32 "<command-line>" 2
......
extern int pclose (FILE *__stream);
extern FILE *popen (const char *__command, const char *__modes)
  __attribute__ ((__malloc__)) ;
extern char *ctermid (char *__s) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1)));
# 867 "/usr/mips-linux-gnu/include/stdio.h" 3
extern void flockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__));
extern int ftrylockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) ;
extern void funlockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__));
# 885 "/usr/mips-linux-gnu/include/stdio.h" 3
extern int __uflow (FILE *);
extern int __overflow (FILE *, int);
# 902 "/usr/mips-linux-gnu/include/stdio.h" 3
# 2 "test.c" 2
# 3 "test.c"
int main() {
 printf("hello world");
 return 0;
}
```

不链接

```
mips-linux-gnu-objdump -DS test.o:

test.o：     文件格式 elf32-tradbigmips


Disassembly of section .text:

00000000 <main>:
   0:	27bdffe0 	addiu	sp,sp,-32
   4:	afbf001c 	sw	ra,28(sp)
   8:	afbe0018 	sw	s8,24(sp)
   c:	03a0f025 	move	s8,sp
  10:	3c1c0000 	lui	gp,0x0
  14:	279c0000 	addiu	gp,gp,0
  18:	afbc0010 	sw	gp,16(sp)
  1c:	3c020000 	lui	v0,0x0
  20:	24440000 	addiu	a0,v0,0
  24:	8f820000 	lw	v0,0(gp)
  28:	0040c825 	move	t9,v0
  2c:	0320f809 	jalr	t9		# jump to 00000000
  30:	00000000 	nop
  34:	8fdc0010 	lw	gp,16(s8)
  38:	00001025 	move	v0,zero
  3c:	03c0e825 	move	sp,s8
  40:	8fbf001c 	lw	ra,28(sp)
  44:	8fbe0018 	lw	s8,24(sp)
  48:	27bd0020 	addiu	sp,sp,32
  4c:	03e00008 	jr	ra
  50:	00000000 	nop
	...

Disassembly of section .reginfo:

00000000 <.reginfo>:
   0:	f2000014 	0xf2000014
	...

Disassembly of section .MIPS.abiflags:

00000000 <.MIPS.abiflags>:
   0:	00002002 	srl	a0,zero,0x0
   4:	01010005 	lsa	zero,t0,at,0x1
	...

Disassembly of section .pdr:

00000000 <.pdr>:
   0:	00000000 	nop
   4:	c0000000 	ll	zero,0(zero)
   8:	fffffffc 	0xfffffffc
	...
  14:	00000020 	add	zero,zero,zero
  18:	0000001e 	0x1e
  1c:	0000001f 	0x1f

Disassembly of section .rodata:

00000000 <.rodata>:
   0:	68656c6c 	0x68656c6c
   4:	6f20776f 	0x6f20776f
   8:	726c6400 	0x726c6400
   c:	00000000 	nop

Disassembly of section .comment:

00000000 <.comment>:
   0:	00474343 	0x474343
   4:	3a202855 	xori	zero,s1,0x2855
   8:	62756e74 	0x62756e74
   c:	75203130 	jalx	480c4c0 <main+0x480c4c0>
  10:	2e332e30 	sltiu	s3,s1,11824
  14:	2d317562 	sltiu	s1,t1,30050
  18:	756e7475 	jalx	5b9d1d4 <main+0x5b9d1d4>
  1c:	31292031 	andi	t1,t1,0x2031
  20:	302e332e 	andi	t6,at,0x332e
  24:	地址 0x0000000000000024 越界。


Disassembly of section .gnu.attributes:

00000000 <.gnu.attributes>:
   0:	41000000 	mftc0	zero,c0_index
   4:	0f676e75 	jal	d9db9d4 <main+0xd9db9d4>
   8:	00010000 	sll	zero,at,0x0
   c:	00070405 	0x70405
```

符合教程中x86-64反汇编的结果

链接

```
mips-linux-gnu-objdump -DS main:

main：     文件格式 elf32-tradbigmips


Disassembly of section .interp:

00400194 <.interp>:
  400194:	2f6c6962 	sltiu	t4,k1,26978
  400198:	2f6c642e 	sltiu	t4,k1,25646
  40019c:	736f2e31 	0x736f2e31
	...

Disassembly of section .MIPS.abiflags:

004001a8 <.MIPS.abiflags>:
  4001a8:	00002002 	srl	a0,zero,0x0
  4001ac:	01010005 	lsa	zero,t0,at,0x1
	...

Disassembly of section .reginfo:

004001c0 <.reginfo>:
  4001c0:	b20000f6 	0xb20000f6
	...
  4001d4:	00419010 	0x419010

Disassembly of section .note.gnu.build-id:

004001d8 <.note.gnu.build-id>:
  4001d8:	00000004 	sllv	zero,zero,zero
  4001dc:	00000014 	0x14
  4001e0:	00000003 	sra	zero,zero,0x0
  4001e4:	474e5500 	bz.w	$w14,4155e8 <_end+0x4588>
  4001e8:	1101e59d 	beq	t0,at,3f9860 <__abi_tag-0x699c>
  4001ec:	28cb0a19 	slti	t3,a2,2585
  4001f0:	bfc660f8 	cache	0x6,24824(s8)
  4001f4:	fd05bdc5 	0xfd05bdc5
  4001f8:	6bb5b1dd 	0x6bb5b1dd
......
```

objdump 参数

```
-D, --disassemble-all    Display assembler contents of all sections
      --disassemble=<sym>  Display assembler contents from <sym>
  -S, --source             Intermix source code with disassembly
      --source-comment[=<txt>] Prefix lines of source code with <txt>
```

* -D显示汇编代码
* -S显示源代码和汇编代码之间的关系

## Thinking 1.2

> Thinking 1.2 思考下述问题：
>
> • 尝试使用我们编写的readelf 程序，解析之前在target 目录下生成的内核ELF 文
>
> 件。
>
> • 也许你会发现我们编写的readelf 程序是不能解析readelf 文件本身的，而我们刚
>
> 才介绍的系统工具readelf 则可以解析，这是为什么呢？（提示：尝试使用readelf
>
> -h，并阅读tools/readelf 目录下的Makefile，观察readelf 与hello 的不同）

```
./readelf ../../target/mos:

0:0x0
1:0x80020000
2:0x80022090
3:0x800220a8
4:0x800220c0
5:0x0
6:0x0
7:0x0
8:0x0
9:0x0
10:0x0
11:0x0
12:0x0
13:0x0
14:0x0
15:0x0
16:0x0
17:0x0
```

```
 ./readelf ./readelf
 # nothing happened
```

现在来探究为什么会这样，首先查看readelf的返回值：

```
./readelf hello > output && echo $?
# 输出0
./readelf ./readelf > output && echo $?
# 输出0
```

可见，readelf正常执行，并没有遇到错误

对两个文件分别执行`readelf -h`

```
hello:
类别:                              ELF32
readelf:
类别:                              ELF64
```

同样的，观察Makefile，可以看到编译hello时加入了选项`-m32`，即编译的hello为ELF32文件，readelf为ELF64文件，我们编写的readelf程序解析的结构为ELF32，显然是无法解析ELF64文件的

验证这个猜想，手动重新编译readelf并且尝试查看它

```
gcc main.c readelf.c -m32 -o test
./readelf test:

0:0x0
1:0x194
2:0x1a8
3:0x1cc
4:0x1ec
5:0x20c
6:0x32c
7:0x41a
8:0x440
9:0x490
10:0x4d8
11:0x1000
12:0x1030
13:0x10f0
14:0x1100
15:0x14e4
16:0x2000
17:0x2050
18:0x2094
19:0x3eb0
20:0x3eb4
21:0x3eb8
22:0x3fb0
23:0x4000
24:0x4008
25:0x0
26:0x0
27:0x0
28:0x0	
```

## Thinking 1.3

> Thinking 1.3 在理论课上我们了解到，MIPS体系结构上电时，启动入口地址为0xBFC00000
>
> （其实启动入口地址是根据具体型号而定的，由硬件逻辑确定，也有可能不是这个地址，但
>
> 一定是一个确定的地址），但实验操作系统的内核入口并没有放在上电启动地址，而是按照
>
> 内存布局图放置。思考为什么这样放置内核还能保证内核入口被正确跳转到？
>
> （提示：思考实验中启动过程的两阶段分别由谁执行。）

此处的地址为虚拟地址，会被mmu转化为实际的硬件地址

## 难点分析

实现printk的时候要注意先弄清楚源文件中的函数关系和函数内容

## 实验体会

实验写是写完了......但是感觉实际上并没有完全理解操作系统的启动过程，需要自己实现的部分不是很多，接受的知识感觉也不是很成体系