# lab2 实验报告

## Thinking 2.1

> Thinking 2.1 请根据上述说明，回答问题：在编写的C 程序中，指针变量中存储的地址
>
> 被视为虚拟地址，还是物理地址？MIPS 汇编程序中lw 和sw 指令使用的地址被视为虚拟
>
> 地址，还是物理地址？

* 虚拟地址
* 虚拟地址

## Thinking 2.2

> Thinking 2.2 请思考下述两个问题：
>
> • 从可重用性的角度，阐述用宏来实现链表的好处。
>
> • 查看实验环境中的/usr/include/sys/queue.h，了解其中单向链表与循环链表的实
>
> 现，比较它们与本实验中使用的双向链表，分析三者在插入与删除操作上的性能差
>
> 异。

* 用宏最大的原因还是因为C语言不支持泛型，用宏才能支持同一段代码适用不同的类型
* `SLIST`只需要维护下一个节点的指针，在插入时比本实验的双向链表更快，但是删除的时候需要从链表头开始遍历找到需要删除的节点，速度变慢
* `CIRCLEQ`的节点地址域跟双向链表类似，只是前节点指针指向前节点而不是前节点的`next`地址从而支持双向遍历，插入和删除的性能都跟双向链表差不多

## Thinking 2.3

> 题目见指导书

**C**

## Thinking 2.4

> Thinking 2.4 请思考下面两个问题：
>
> • 请阅读上面有关TLB 的描述，从虚拟内存和多进程操作系统的实现角度，阐述ASID
>
> 的必要性。
>
> • 请阅读MIPS 4Kc 文档《MIPS32® 4K™ Processor Core Family Software User’s
>
> Manual》的Section 3.3.1 与Section 3.4，结合ASID 段的位数，说明4Kc 中可容纳
>
> 不同的地址空间的最大数量。

* 不同进程，不同程序角度下的虚拟内存空间是相同的，这个时候就需要用ASID来区分不同的进程，保证内存在进程之间是隔离的
* ASID 8位，可容纳256段

## Thinking 2.5

> Thinking 2.5 请回答下述三个问题：
>
> • tlb_invalidate 和tlb_out 的调用关系？
>
> • 请用一句话概括tlb_invalidate 的作用。
>
> • 逐行解释tlb_out 中的汇编代码。

* `tlb_invalidate`调用`tlb_out`

* 调用`tlb_out`，清空va，asid的tlb

* ```
  LEAF(tlb_out)
  .set noreorder
  	mfc0    t0, CP0_ENTRYHI		# save ENTRYHI
  	mtc0    a0, CP0_ENTRYHI		# write tlb key into ENTRYHI
  	nop							# nop
  	/* Step 1: Use 'tlbp' to probe TLB entry */
  	/* Exercise 2.8: Your code here. (1/2) */
  	tlbp						# find tlb, save index into INDEX
  
  	nop							# nop
  	/* Step 2: Fetch the probe result from CP0.Index */
  	mfc0    t1, CP0_INDEX		# load INDEX into t1
  .set reorder
  	bltz    t1, NO_SUCH_ENTRY	# jump to NO_SUCH_ENTRY if t1 < 0
  .set noreorder
  	mtc0    zero, CP0_ENTRYHI	# write 0 to ENTRYHI
  	mtc0    zero, CP0_ENTRYLO0	# write 0 to ENTRYLO0
  	mtc0    zero, CP0_ENTRYLO1	# write 0 to ENTRYLO1
  	nop
  	/* Step 3: Use 'tlbwi' to write CP0.EntryHi/Lo into TLB at CP0.Index  */
  	/* Exercise 2.8: Your code here. (2/2) */
  	tlbwi						# write ENTRYHI, ENTRYLO0, ENTRYLO1 to tbl according to INDEX
  
  .set reorder
  
  NO_SUCH_ENTRY:					# restore ENTRYHI, jump to return address
  	mtc0    t0, CP0_ENTRYHI
  	j       ra
  END(tlb_out)
  ```

## thinking 2.6

> Thinking 2.6 从下述三个问题中任选其一回答：
>
> • 简单了解并叙述X86 体系结构中的内存管理机制，比较X86 和MIPS 在内存管理上
>
> 的区别。
>
> • 简单了解并叙述RISC-V 中的内存管理机制，比较RISC-V 与MIPS 在内存管理上
>
> 的区别。
>
> • 简单了解并叙述LoongArch 中的内存管理机制，比较LoongArch 与MIPS 在内存
>
> 管理上的区别。

RISC-V同样支持虚拟内存，同样用页表管理内存，同样将内存管理交给操作系统负责

与mips不同，RISC-V设计了三种特权等级（比mips多一种）

在RISC-V中，tlb的管理是由操作系统负责的

mips通常采用二级页表，RISC-V可以选择一级或二级

页表权限位有一定定义上的不同设计