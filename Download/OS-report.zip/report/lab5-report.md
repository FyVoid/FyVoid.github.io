# Lab5 Report

## Thinking 5.1

> Thinking 5.1 如果通过kseg0 读写设备，那么对于设备的写入会缓存到Cache 中。这是
>
> 一种错误的行为，在实际编写代码的时候这么做会引发不可预知的问题。请思考：这么做
>
> 这会引发什么问题？对于不同种类的设备（如我们提到的串口设备和IDE 磁盘）的操作会
>
> 有差异吗？可以从缓存的性质和缓存更新的策略来考虑。

* 外设数据的改变会导致内存改变，但是cache不会被更新，kseg0中的数据会优先访问cache，cache中的数据没有更新，从而导致错误。
* 磁盘以块为单位进行读写，而且读写相对密集，写的时候相应的内存会标记为 dirty，同时更新缓存，因此这种错误对磁盘出现概率较小；相对地，串口设备等设备就很容易发生这种错误。

## Thinking 5.2

> Thinking 5.2 查找代码中的相关定义，试回答一个磁盘块中最多能存储多少个文件控制
>
> 块？一个目录下最多能有多少个文件？我们的文件系统支持的单个文件最大为多大？

```
// max block count
BLOCKSIZE / FILE_STRUCT_SIZE = 16

// max file count
NINDIRECT * 16 = 1024 * 16 = 16384

// max file size
MAXFILESIZE = NINDIRECT * BLOCKSIZE = 4194304 = 4MB
```

## Thinking 5.3

> Thinking 5.3 请思考，在满足磁盘块缓存的设计的前提下，我们实验使用的内核支持的最大磁盘大小是多少？

缓存和磁盘块为1-1映射，缓存大小1GB，磁盘块最大大小也是1GB

## Thinking 5.4

> Thinking 5.4 在本实验中，fs/serv.h、user/include/fs.h 等文件中出现了许多宏定义，
>
> 试列举你认为较为重要的宏定义，同时进行解释，并描述其主要应用之处。

### fs.h

```
// some discriptions of block
#define FBLOCK_SIZE PAGE_SIZE
#define BLOCK_SIZE_BIT (BLOCK_SIZE * 8)

// Maximum size of a filename (a single path component), including null
#define MAXNAMELEN 128

// Maximum size of a complete pathname, including null
#define MAXPATHLEN 1024

// Number of (direct) block pointers in a File descriptor
#define NDIRECT 10
#define NINDIRECT (BLOCK_SIZE / 4)

#define MAXFILESIZE (NINDIRECT * BLOCK_SIZE)

#define FILE_STRUCT_SIZE 256

// File types
#define FTYPE_REG 0 // Regular file
#define FTYPE_DIR 1 // Directory
// used to identify file type

#define FS_MAGIC 0x68286097 // Everyone's favorite OS class
// Mit cs 6.828
```

### serv.h

```
#define PTE_DIRTY 0x0004 // file system block cache is dirty

#define SECT_SIZE 512			  /* Bytes per disk sector */
#define SECT2BLK (BLOCK_SIZE / SECT_SIZE) /* sectors to a block */

/* Disk block n, when in memory, is mapped into the file system
 * server's address space at DISKMAP+(n*BLOCK_SIZE). */
#define DISKMAP 0x10000000
// used in disk_addr()

/* Maximum disk size we can handle (1GB) */
#define DISKMAX 0x40000000
```

## Thinking 5.5

> Thinking 5.5 在Lab4“系统调用与fork”的实验中我们实现了极为重要的fork 函数。那
>
> 么fork 前后的父子进程是否会共享文件描述符和定位指针呢？请在完成上述练习的基础上
>
> 编写一个程序进行验证。

会，创建一个test，修改其内容为：

```
#include "../../fs/serv.h"
#include <lib.h>

int main() {
	char buffer[256];
	int fd_num = open("/newmotd", O_RDONLY);
	int bytes;
	if (fork() == 0) {
		bytes = read(fd_num, buffer, 8);
		debugf("child buffer: %s\n", buffer);
	} else {
		bytes = read(fd_num, buffer, 8);
		debugf("parent buffer: %s\n", buffer);
	}
}

```

运行test观察输出

```
make test lab=5_114514 && make run

// compile information
...

FS is running
superblock is good
read_bitmap is good
parent buffer: This is
child buffer: the NEW
[00000800] destroying 00000800
[00000800] free env 00000800
i am killed ...
[00001802] destroying 00001802
[00001802] free env 00001802
i am killed ...
panic at sched.c:45 (schedule): 'TAILQ_EMPTY(&env_sched_list)' returned 1
ra:    80026080  sp:  803ffe78  Status: 00008000
Cause: 00000420  EPC: 00402de0  BadVA:  7fd7f004
curenv:    NULL
cur_pgdir: 83fce000
```

## Thinking 5.6

> Thinking 5.6 请解释File, Fd, Filefd 结构体及其各个域的作用。比如各个结构体会在哪
>
> 些过程中被使用，是否对应磁盘上的物理实体还是单纯的内存数据等。说明形式自定，要
>
> 求简洁明了，可大致勾勒出文件系统数据结构与物理实体的对应关系与设计框架。

```
struct File {
	char f_name[MAXNAMELEN]; // filename
	uint32_t f_size;	 // file size in bytes
	uint32_t f_type;	 // file type
	uint32_t f_direct[NDIRECT];	// pointers to direct blocks
	uint32_t f_indirect;		// pointers to indirect blocks

	struct File *f_dir; // the pointer to the dir where this file is in, valid only in memory.
	char f_pad[FILE_STRUCT_SIZE - MAXNAMELEN - (3 + NDIRECT) * 4 - sizeof(void *)];
} __attribute__((aligned(4), packed));

struct Fd {
	u_int fd_dev_id;		// id
	u_int fd_offset;		// offset, mark position for io
	u_int fd_omode;			// mode, discribe RW
};

struct Filefd {
	struct Fd f_fd;			// fd
	u_int f_fileid;			// id
	struct File f_file;	// linked file block
};
```

## Thinking 5.7

> Thinking 5.7 图5.9 中有多种不同形式的箭头，请解释这些不同箭头的差别，并思考我们
>
> 的操作系统是如何实现对应类型的进程间通信的。

* 黑色实线+箭头+黑点：init进程创建fs子进程用作文件系统，并创建用户程序进程
* 虚线：进程执行顺序
* 黑色实线+箭头：用户程序向文件进程发出io请求
* 黑色虚线：文件进程向用户程序发送文件数据

实线：同步信息，会导致线程停止等待同步

虚线：异步信息，不等待同步