# Lab6 Report

## 6.1

> Thinking 6.1 示例代码中，父进程操作管道的写端，子进程操作管道的读端。如果现在想
>
> 让父进程作为“读者”，代码应当如何修改？

调整（相反）关闭的端口就行

```
int main() {
   	
    switch (fork()) {
        case -1 : 
            break;
            
        case 0 :
            close(fildes[0]); /* Read end is unused */
            write(fildes[1], "Hello world\n", 12); /* Write data on pipe */
            close(fildes[1]); /* Child will see EOF */
            exit(0);
            
        default :
            close(fildes[1]); /* Write end is unused */
            read(fildes[0], buf, 100); /* Get data from pipe */
            printf("child-process read:%s",buf); /* Print the data */
            close(fildes[0]); /* Finished with pipe */
            exit(0);
            
    }
}
```

## 6.2

> Thinking 6.2 上面这种不同步修改 pp_ref 而导致的进程竞争问题在user/lib/fd.c 中
>
> 的dup 函数中也存在。请结合代码模仿上述情景，分析一下我们的 dup 函数中为什么会出
>
> 现预想之外的情况？

`dup`函数会将一个文件描述符完全复制给另一个文件描述符，复制过程中，会将文件描述符本身和文件描述符的数据先后映射到新的文件描述符

如果在已经完成了复制本身，但是还没有完成复制pipe的情况下发生了中断，可能会导致系统认为进程关闭，发送错误，例如以下代码段

```
if (fork() == 0) {
    read(p[0], buf, sizeof(buf));
} else {  
    dup(p[0], new_fd);
    write(p[1], "Hello", 5);
}
```

## 6.3

> Thinking 6.3 阅读上述材料并思考：为什么系统调用一定是原子操作呢？如果你觉得不是
>
> 所有的系统调用都是原子操作，请给出反例。希望能结合相关代码进行分析说明。

结合CO p7的内容，mips CPU在陷入内核态时会屏蔽所有中断，因此是原子操作

## 6.4

> Thinking 6.4 仔细阅读上面这段话，并思考下列问题
>
> • 按照上述说法控制 pipe_close 中 fd 和 pipe unmap 的顺序，是否可以解决上述场
>
> 景的进程竞争问题？给出你的分析过程。
>
> • 我们只分析了 close 时的情形，在 fd.c 中有一个 dup 函数，用于复制文件描述符。
>
> 试想，如果要复制的文件描述符指向一个管道，那么是否会出现与 close 类似的问
>
> 题？请模仿上述材料写写你的理解。

* 可以，调整顺序后满足`page_ref(fd) < page_ref(pipe)`恒成立，产生竞争错误的条件不会被满足
* 如**6.2**中描述的，可能产生错误

## 6.5

> Thinking 6.5 思考以下三个问题。
>
> • 认真回看Lab5 文件系统相关代码，弄清打开文件的过程。
>
> • 回顾Lab1 与Lab3，思考如何读取并加载ELF 文件。
>
> • 在Lab1 中我们介绍了 data text bss 段及它们的含义，data 段存放初始化过的全
>
> 局变量，bss 段存放未初始化的全局变量。关于memsize 和filesize ，我们在Note
>
> 1.3.4中也解释了它们的含义与特点。关于Note 1.3.4，注意其中关于“bss 段并不在文
>
> 件中占数据”表述的含义。回顾Lab3并思考：elf_load_seg()和load_icode_mapper()
>
> 函数是如何确保加载ELF 文件时，bss 段数据被正确加载进虚拟内存空间。bss 段
>
> 在ELF 中并不占空间，但ELF 加载进内存后，bss 段的数据占据了空间，并且初始
>
> 值都是0。请回顾elf_load_seg() 和load_icode_mapper() 的实现，思考这一点
>
> 是如何实现的？

* 在`user/lib/files.c`文件中，`open`函数调用了同目录下的`fsipc_open`函数。`fsipc_open`函数通过调用`fsipc`函数与服务进程进行进程间通信，并接收返回的消息。文件系统服务进程中的`serve_open`函数随后调用`file_open`函数来打开文件。最终，这个过程通过`fsipc`实现了用户进程与文件描述符的共享。
* 调用`load_icode`，将elf文件作为二进制文件打开并保存为char数组
* `elf_load_seg`函数中的`map_page`（即`load_icode_mapper`）完成了对虚拟空间的映射和初始化为0

## 6.6

> Thinking 6.6 通过阅读代码空白段的注释我们知道，将标准输入或输出定向到文件，需要
>
> 我们将其dup 到0 或1 号文件描述符（fd）。那么问题来了：在哪步，0 和1 被“安排”为
>
> 标准输入和标准输出？请分析代码执行流程，给出答案。

在以下代码段中可以找到答案

```
// in user/init.c main()

...

// stdin should be 0, because no file descriptors are open yet
	if ((r = opencons()) != 0) {
		user_panic("opencons: %d", r);
	}
	// stdout
	if ((r = dup(0, 1)) < 0) {
		user_panic("dup: %d", r);
	}
```

## 6.7

> Thinking 6.7 在shell 中执行的命令分为内置命令和外部命令。在执行内置命令时shell 不
>
> 需要fork 一个子shell，如Linux 系统中的cd 命令。在执行外部命令时shell 需要fork
>
> 一个子shell，然后子shell 去执行这条命令。
>
> 据此判断，在MOS 中我们用到的shell 命令是内置命令还是外部命令？请思考为什么
>
> Linux 的cd 命令是内部命令而不是外部命令？

* mos的shell为外部命令（完全依赖外部文件）
* 显然，内部命令速度远快于外部命令，linux中cd非常常用，因此被设定为内部命令

## 6.8

> Thinking 6.8 在你的shell 中输入命令ls.b | cat.b > motd。
>
> • 请问你可以在你的shell 中观察到几次spawn ？分别对应哪个进程？
>
> • 请问你可以在你的shell 中观察到几次进程销毁？分别对应哪个进程？

```
[00002803] pipecreate
[00003805] destroying 00003805
[00003805] free env 00003805
i am killed ...
[00004006] destroying 00004006
[00004006] free env 00004006
i am killed ...
[00003004] destroying 00003004
[00003004] free env 00003004
i am killed ...
[00002803] destroying 00002803
[00002803] free env 00002803
i am killed ...
```

调用spawn的部分

* 执行ls.b和cat.b，共两次

进程销毁了四次

* shell和其他三个指令
