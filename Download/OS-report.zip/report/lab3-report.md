# lab3实验报告

## Thinking 3.1

> Thinking 3.1 请结合MOS中的页目录自映射应用解释代码中e->env_pgdir[PDX(UVPT)] = PADDR(e->env_pgdir) | PTE_V 的含义。

`UVPT`为用户页表起始的虚拟地址，`PDX(UVPT)`为其页号，`e->env_pgdir`为`e`的页目录，此处为将`e`页目录中用户页表起始页写为其物理地址加上验证位

## Thinking 3.2

> Thinking 3.2 elf_load_seg 以函数指针的形式，接受外部自定义的回调函数map_page。
>
> 请你找到与之相关的data 这一参数在此处的来源，并思考它的作用。没有这个参数可不可以？为什么？

`elf_load_seg`调用：

```
panic_on(elf_load_seg(ph, binary + ph->p_offset, load_icode_mapper, e));
```

`e`为`Env`，此处通过调用该函数，调用`load_icode_mapper`完成了对`e`的map

`e`在此处提供了进程控制块的信息，如asid等

## Thinking 3.3

> Thinking 3.3 结合 elf_load_seg 的参数和实现，考虑该函数需要处理哪些页面加载的情况。

* va是否页对齐，不对齐的话需要将多余的offset写到对应页
* 需要将段内的页映射到物理地址
* 对内存中多出的位置补零

## Thinking 3.4

> Thinking 3.4 思考上面这一段话，并根据自己在Lab2 中的理解，回答：
>
> • 你认为这里的 env_tf.cp0_epc 存储的是物理地址还是虚拟地址?

虚拟地址

## Thinking 3.5

> Thinking 3.5 试找出0、1、2、3 号异常处理函数的具体实现位置。8 号异常（系统调用）
>
> 涉及的 do_syscall() 函数将在Lab4 中实现。

实现位置在`kern/genex.S`

```
#include <asm/asm.h>
#include <stackframe.h>

.macro BUILD_HANDLER exception handler
NESTED(handle_\exception, TF_SIZE + 8, zero)
	move    a0, sp
	addiu   sp, sp, -8
	jal     \handler
	addiu   sp, sp, 8
	j       ret_from_exception
END(handle_\exception)
.endm

.text

FEXPORT(ret_from_exception)
	RESTORE_ALL
	eret

NESTED(handle_int, TF_SIZE, zero)
	mfc0    t0, CP0_CAUSE
	mfc0    t2, CP0_STATUS
	and     t0, t2
	andi    t1, t0, STATUS_IM7
	bnez    t1, timer_irq
timer_irq:
	li      a0, 0
	j       schedule
END(handle_int)

BUILD_HANDLER tlb do_tlb_refill

#if !defined(LAB) || LAB >= 4
BUILD_HANDLER mod do_tlb_mod
BUILD_HANDLER sys do_syscall
#endif

BUILD_HANDLER reserved do_reserved
```

## Thinking 3.6

> Thinking 3.6 阅读entry.S、genex.S 和env_asm.S 这几个文件，并尝试说出时钟中断
>
> 在哪些时候开启，在哪些时候关闭。

在init后开启，进入异常处理时关闭，退出异常处理时开启

## Thinking 3.7

> Thinking 3.7 阅读相关代码，思考操作系统是怎么根据时钟中断切换进程的。

依靠时钟中断时中断处理跳转到`schedule`来切换进程，具体如下

```
void schedule(int yield) {
	static int count = 0; // remaining time slices of current env
	struct Env *e = curenv;

	// check for reschedule conditions, if not, just decrease count
	if (yield || count <= 0 || e == NULL || e->env_status != ENV_RUNNABLE) {
		// if we need to reschedule and current env is not null
		// remove e from sched_list and set its status to RUNNABLE, insert e to tail
		if (e != NULL) {
			TAILQ_REMOVE(&env_sched_list, e, env_sched_link);
			if (e->env_status == ENV_RUNNABLE) {
				TAILQ_INSERT_TAIL(&env_sched_list, e, env_sched_link);	
			}
		}
		panic_on(TAILQ_EMPTY(&env_sched_list));
		e = TAILQ_FIRST(&env_sched_list);	// get the first of sched list
		count = e->env_pri;								// set count to its pri
	}
	// decrese count and run env e
	count--;
	env_run(e);

}
```

