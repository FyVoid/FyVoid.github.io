# lab0 实验报告

## 实验内容

lab0主要涉及linux系统命令行的基本操作和常用命令行工具的使用

### 难点分析

主要讲究熟练度，另外需要多尝试`sed`和`awk`，熟练这两个工具的使用。

写bash脚本时要注意bash的语法中别扭的地方

### 实验体会

已经比较熟悉命令行，没什么特别体会

**注意要看清楚题目里面编译目标的名称**

## Thinking 0.1

> Thinking 0.1 思考下列有关Git 的问题：
>
> • 在前述已初始化的~/learnGit 目录下，创建一个名为README.txt 的文件。执
>
> 行命令git status > Untracked.txt（其中的> 为输出重定向，我们将在0.6.3 中
>
> 详细介绍）。
>
> • 在README.txt 文件中添加任意文件内容，然后使用add 命令，再执行命令git
>
> status > Stage.txt。
>
> • 提交README.txt，并在提交说明里写入自己的学号。
>
> • 执行命令cat Untracked.txt 和cat Stage.txt，对比两次运行的结果，体会
>
> README.txt 两次所处位置的不同。
>
> • 修改README.txt 文件，再执行命令git status > Modified.txt。
>
> • 执行命令cat Modified.txt，观察其结果和第一次执行add 命令之前的status 是
>
> 否一样，并思考原因。

```
Untracked.txt:
位于分支 master

尚无提交

未跟踪的文件:
  （使用 "git add <文件>..." 以包含要提交的内容）
	README.md
	Untracked.txt

提交为空，但是存在尚未跟踪的文件（使用 "git add" 建立跟踪）

Stage.txt:
位于分支 master

尚无提交

要提交的变更：
  （使用 "git rm --cached <文件>..." 以取消暂存）
	新文件：   README.md

未跟踪的文件:
  （使用 "git add <文件>..." 以包含要提交的内容）
	Stage.txt
	Untracked.txt
	
Modified.txt:
位于分支 master

尚无提交

要提交的变更：
  （使用 "git rm --cached <文件>..." 以取消暂存）
	新文件：   README.md

尚未暂存以备提交的变更：
  （使用 "git add <文件>..." 更新要提交的内容）
  （使用 "git restore <文件>..." 丢弃工作区的改动）
	修改：     README.md

未跟踪的文件:
  （使用 "git add <文件>..." 以包含要提交的内容）
	Modified.txt
	Stage.txt
	Untracked.txt
```

由于README.md在加入暂存区后又被修改了，所以结果和第一次add之前不同



## Thinking 0.2

> Thinking 0.2 仔细看看0.10，思考一下箭头中的add the file、stage the file 和
>
> commit 分别对应的是Git 里的哪些命令呢？

```
add the file: git add
stage the file: git add
commit: git commit
```

## Thinking 0.3

> Thinking 0.3 思考下列问题：
>
> 1. 代码文件print.c 被错误删除时，应当使用什么命令将其恢复？
> 2. 代码文件print.c 被错误删除后，执行了git rm print.c 命令，此时应当
>
> 使用什么命令将其恢复？
>
> 3. 无关文件hello.txt 已经被添加到暂存区时，如何在不删除此文件的前提下将其移出暂存区？

```
1. 
git restore print.c
2. 
git reset HEAD print.c
git restore print.c
3.
git rm --cached hello.txt
```

## Thinking 0.4

> Thinking 0.4 思考下列有关Git 的问题：
>
> • 找到在/home/22xxxxxx/learnGit 下刚刚创建的README.txt 文件，若不存
>
> 在则新建该文件。
>
> • 在文件里加入Testing 1，git add，git commit，提交说明记为1。
>
> • 模仿上述做法，把1 分别改为2 和3，再提交两次。
>
> • 使用git log 命令查看提交日志，看是否已经有三次提交，记下提交说明为
>
> 3 的哈希值a
>
> 。
>
> • 进行版本回退。执行命令git reset --hard HEAD^ 后，再执行git log，观
>
> 察其变化。
>
> • 找到提交说明为1 的哈希值，执行命令git reset --hard <hash> 后，再执
>
> 行git log，观察其变化。
>
> • 现在已经回到了旧版本，为了再次回到新版本，执行git reset --hard <hash>
>
> ，再执行git log，观察其变化。
>
> ■
>
> a使用git log 命令时，在commit 标识符后的一长串数字和字母组成的字符串

```
git log:
commit cda56aa54f66d69820abd9277f720740aca76d97 (HEAD -> master)
Author: 
Date:   Mon Mar 11 11:57:27 2024 +0800

    3

commit b7da8600f5968386d0f6517904f49ee14c8bd61b
Author: 
Date:   Mon Mar 11 11:57:08 2024 +0800

    2

commit fe6f31dae5337c45e5038356a68b008b8820783f
Author: 
Date:   Mon Mar 11 11:56:35 2024 +0800

    1
    
git reset -- hard HEAD^ && cat README.md:
Testing 2

git reset --hard fe6f31dae5337c45e5038356a68b008b8820783f && cat README.md
Testing 1
git log:
commit fe6f31dae5337c45e5038356a68b008b8820783f (HEAD -> master)
Author: 
Date:   Mon Mar 11 11:56:35 2024 +0800

    1
    
git reset --hard cda56aa54f66d69820abd9277f720740aca76d97
git log:
commit cda56aa54f66d69820abd9277f720740aca76d97 (HEAD -> master)
Author: 
Date:   Mon Mar 11 11:57:27 2024 +0800

    3

commit b7da8600f5968386d0f6517904f49ee14c8bd61b
Author: 
Date:   Mon Mar 11 11:57:08 2024 +0800

    2

commit fe6f31dae5337c45e5038356a68b008b8820783f
Author: 
Date:   Mon Mar 11 11:56:35 2024 +0800

    1
```

## Thinking 0.5

> Thinking 0.5 执行如下命令, 并查看结果
>
> • echo first
>
> • echo second > output.txt
>
> • echo third > output.txt
>
> • echo forth >> output.txt

```
echo first:
first

echo second > output.txt && cat output.txt:
second

echo third > output.txt && cat output.txt:
third

echo forth >> output.txt && cat output.txt:
third
forth
```

## Thinking 0.6

> Thinking 0.6 使用你知道的方法（包括重定向）创建下图内容的文件（文件命名为test），
>
> 将创建该文件的命令序列保存在command 文件中，并将test 文件作为批处理文件运行，将
>
> 运行结果输出至result 文件中。给出command 文件和result 文件的内容，并对最后的结
>
> 果进行解释说明（可以从test 文件的内容入手）. 具体实现的过程中思考下列问题: echo
>
> echo Shell Start 与echo `echo Shell Start` 效果是否有区别; echo echo $c>file1
>
> 与echo `echo $c>file1` 效果是否有区别.

```
command.sh:
printf "
echo Shell Start...
echo set a = 1
a=1	# a is set to 1
echo set b = 2
b=2	# b is set to 2
echo set c = a + b
c=$[$a+$b]	# use a + b to set c
echo c = $c	# use echo to show c's value
echo save c to ./file1
echo $c > file1	# echo $c and save output to file1
echo save b to ./file2
echo $b > file2	# echo $b and save output to file2
echo save a to ./file3
echo $a > file3	# echo $a and save output to file3
echo save file1 file2 file3 to file4
cat file1 file2 file3 > file4	# save content of file1, file2, file3 to file4
echo save file4 to ./result
cat file4 >> result	# save content of file4 to result
"
```



```
test.sh:
echo Shell Start...
echo set a = 1
a=1	# a is set to 1
echo set b = 2
b=2	# b is set to 2
echo set c = a + b
c=$[$a+$b]	# use a + b to set c
echo c = $c	# use echo to show c's value
echo save c to ./file1
echo $c > file1	# echo $c and save output to file1
echo save b to ./file2
echo $b > file2	# echo $b and save output to file2
echo save a to ./file3
echo $a > file3	# echo $a and save output to file3
echo save file1 file2 file3 to file4
cat file1 file2 file3 > file4	# save content of file1, file2, file3 to file4
echo save file4 to ./result
cat file4 >> result	# save content of file4 to result
```

* 没有区别
* 有区别